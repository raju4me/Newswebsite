from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class EmailValidation(forms.EmailField):
    def validate(self, value):
        try:
            User.objects.get(email=value)
            raise forms.ValidationError("Email already exists")
        except User.MultipleObjectsReturned:
            raise forms.ValidationError("Email already exists")
        except User.DoesNotExist:
            pass
        
# class UsernameValidation(forms.CharField):
#     def validate(self, value):
#         if len(value) <10:
#             raise forms.ValidationError("Length of username must be 10 or greater than 10")

class UserSignupForm(UserCreationForm):
    email = EmailValidation(required=True)
    class Meta:
        model = User
        fields = ('email', 'username', 'first_name', 'last_name')